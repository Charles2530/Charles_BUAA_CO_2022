p5自动化测试脚本

1.compile.cmd运行出随机生成的程序

2.verdi.cmd 实现将输出文件放入工程中

3.finish.cmd实现mips和isim输出及文本比较

